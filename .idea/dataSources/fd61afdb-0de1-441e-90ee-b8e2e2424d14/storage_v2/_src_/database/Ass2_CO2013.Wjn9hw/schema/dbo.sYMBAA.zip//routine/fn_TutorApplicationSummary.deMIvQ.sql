

CREATE FUNCTION dbo.fn_TutorApplicationSummary
(
    @tutor_id INT
)
RETURNS @ResultTable TABLE
(
    tutor_id INT,
    accepted_count INT,
    denied_count INT,
    error_message NVARCHAR(255)
)
AS
BEGIN
    -- Kiểm tra tham số đầu vào
    IF @tutor_id IS NULL OR @tutor_id <= 0
    BEGIN
        INSERT INTO @ResultTable (tutor_id, accepted_count, denied_count, error_message)
        VALUES (NULL, NULL, NULL, 'Invalid tutor_id');
        RETURN;
    END;

    -- Biến lưu trữ tạm thời
    DECLARE @accepted_count INT = 0;
    DECLARE @denied_count INT = 0;

    -- Tính số lượng đơn "chấp nhận" 
    SELECT @accepted_count = COUNT(*)
    FROM dbo.teaching_application
    WHERE tutor_id = @tutor_id
      AND application_status IN ('chap nhan');

    -- Tính số lượng đơn "từ chối" 
    SELECT @denied_count = COUNT(*)
    FROM dbo.teaching_application
    WHERE tutor_id = @tutor_id
      AND application_status IN ('tu choi');

    -- Sử dụng vòng lặp để minh họa (loop thêm 1 dòng mỗi lần lặp)
    DECLARE @i INT = 0;
    WHILE @i < 1
    BEGIN
        INSERT INTO @ResultTable (tutor_id, accepted_count, denied_count, error_message)
        VALUES (@tutor_id, @accepted_count, @denied_count, NULL);

        SET @i = @i + 1;
    END;

    RETURN;
END;
go

