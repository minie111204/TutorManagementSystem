

-- Create the stored procedure in the specified schema
CREATE PROCEDURE dbo.insert_is_held_on
    @class_id BIGINT,
    @time_list TIME_LIST READONLY
-- add more stored procedure parameters here
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        -- can be updated for the update use-case
        -- checking for class_id
        IF NOT EXISTS 
            (
                SELECT 1
                FROM dbo.class c  
                WHERE c.class_id = @class_id
            )
            THROW 50003, 'Class has been altered or deleted', 1;

        -- checking for slot_id
        IF EXISTS 
            (
                SELECT 1
                FROM @time_list l 
                WHERE l.week_id NOT IN 
                (
                    SELECT w.week_id
                    FROM dbo.week_day w
                )
            )
            OR 
            EXISTS 
            (
                SELECT 1
                FROM @time_list l 
                WHERE l.slot_id NOT IN 
                (
                    SELECT t.slot_id
                    FROM dbo.time_slot t
                )
            )
            THROW 50006, 'Weekdays or times are not allowed to choose', 1;


        -- delete from update
        DELETE FROM dbo.is_held_on
        WHERE class_id = @class_id;

        INSERT INTO dbo.is_held_on
        SELECT @class_id, t.week_id, t.slot_id
        FROM @time_list t;

    END TRY 

    BEGIN CATCH 
        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application to show error
        THROW;
    END CATCH
END
go

