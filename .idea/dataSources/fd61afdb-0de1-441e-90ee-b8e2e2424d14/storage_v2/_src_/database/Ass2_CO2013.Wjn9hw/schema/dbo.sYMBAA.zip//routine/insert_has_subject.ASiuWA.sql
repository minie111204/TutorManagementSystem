

-- Create the stored procedure in the specified schema
CREATE PROCEDURE dbo.insert_has_subject
    @class_id BIGINT,
    @subject_id_list SUBJECT_ID_LIST READONLY
AS
BEGIN

    SET NOCOUNT ON;

    BEGIN TRY 

        -- can be updated for the update use-case
        -- checking for class_id
        IF NOT EXISTS 
            (
                SELECT 1
                FROM dbo.class c  
                WHERE c.class_id = @class_id
            )
            THROW 50003, 'Class has been altered or deleted', 1;

        -- checking for the subject_id
        IF EXISTS 
            (
                SELECT 1
                FROM @subject_id_list l
                WHERE l.subject_id NOT IN 
                (
                    SELECT s.subject_id
                    FROM dbo.subject s
                )
            )
            THROW 50004, 'One or more subjects do not exist', 1;

        -- deleting any links
        -- for updating
        DELETE FROM dbo.has_subject 
        WHERE class_id = @class_id; 

        INSERT INTO dbo.has_subject(class_id, subject_id)
        SELECT @class_id, l.subject_id
        FROM @subject_id_list l;

    END TRY

    BEGIN CATCH
        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application to show error
        THROW;
    END CATCH
END
go

