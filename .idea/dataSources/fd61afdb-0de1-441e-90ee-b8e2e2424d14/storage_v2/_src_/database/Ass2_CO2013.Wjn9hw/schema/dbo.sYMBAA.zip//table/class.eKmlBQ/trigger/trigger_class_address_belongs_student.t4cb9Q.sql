

CREATE   TRIGGER trigger_class_address_belongs_student
ON [dbo].[class]
AFTER INSERT, UPDATE
AS
BEGIN
    DECLARE 
        @student_id BIGINT, 
        @addr_id BIGINT;

    SELECT 
        @student_id = student_id,      -- NOT NULL
        @addr_id    = addr_id          -- NOT NULL
    FROM inserted;

    IF 
    (
        @addr_id NOT IN 
        (
            SELECT a.addr_id
            FROM dbo.address a  
            WHERE a.user_id = @student_id
        )
    )
    BEGIN
        ROLLBACK TRANSACTION;
        THROW 50009, 'Student does not have the address', 1;
    END
END;
go

