

--SELECT * FROM dbo.Calculate_Revenue_Subject(9999);  -- Môn học với ID không tồn tại


--drop FUNCTION Calculate_Revenue
--SELECT * FROM [Ass2_CO2013].[dbo].Calculate_Revenue('Subject', 'Toan');
CREATE FUNCTION Calculate_Revenue(@Types VARCHAR(255), @InputValues VARCHAR(255))
RETURNS @ResultProfit TABLE (
    Current_Revenue     DECIMAL(18, 2) DEFAULT 0,
    Expected_Revenue    DECIMAL(18, 2) DEFAULT 0,
    Discount_Revenue    DECIMAL(18, 2) DEFAULT 0,
    Error_Message       NVARCHAR(255) NULL -- Cột thông báo lỗi
)
AS
BEGIN
    -- Kiểm tra giá trị đầu vào
    IF (@Types IS NULL OR @Types = '') 
    BEGIN
        INSERT INTO @ResultProfit (Current_Revenue, Expected_Revenue, Discount_Revenue, Error_Message)
        VALUES (NULL, NULL, NULL, 'Invalid type');
        RETURN;
    END;

    IF (@InputValues IS NULL OR @InputValues = '') AND @Types != 'ALL'
    BEGIN
        INSERT INTO @ResultProfit (Current_Revenue, Expected_Revenue, Discount_Revenue, Error_Message)
        VALUES (NULL, NULL, NULL, 'Invalid input values');
        RETURN;
    END;

    -- Logic tính toán theo loại lọc
    IF (@Types = 'ALL')
    BEGIN
        INSERT INTO @ResultProfit 
        SELECT Current_Revenue, Expected_Revenue, Discount_Revenue, NULL
        FROM [Ass2_CO2013].[dbo].Calculate_Revenue_All();
        RETURN;
    END;

    IF (@Types = 'Subject')
    BEGIN
        DECLARE @SubjectID BIGINT;

        -- Tìm ID môn học từ tên môn học
        SELECT @SubjectID = subject_id
        FROM [Ass2_CO2013].[dbo].subject 
        WHERE @InputValues = subject_name;

        -- Kiểm tra nếu môn học không tồn tại
        IF @SubjectID IS NULL 
        BEGIN
            -- Nếu môn học không tồn tại, trả về thông báo lỗi và NULL cho các cột doanh thu
            INSERT INTO @ResultProfit (Current_Revenue, Expected_Revenue, Discount_Revenue, Error_Message)
            VALUES (NULL, NULL, NULL, 'Subject does not exist');
            RETURN;
        END;

        -- Nếu môn học tồn tại, tính toán doanh thu cho môn học đó
        INSERT INTO @ResultProfit 
        SELECT Current_Revenue, Expected_Revenue, Discount_Revenue, NULL
        FROM [Ass2_CO2013].[dbo].Calculate_Revenue_Subject(@SubjectID);
        RETURN;
    END;

    -- Trường hợp không xác định
    INSERT INTO @ResultProfit (Current_Revenue, Expected_Revenue, Discount_Revenue, Error_Message)
    VALUES (NULL, NULL, NULL, 'Invalid parameters');
    RETURN;
END;

-- Test Case: Tính toán doanh thu cho môn học "Toán"
--SELECT * FROM dbo.Calculate_Revenue('Subject', 'Toan');
go

