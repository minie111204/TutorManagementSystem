

-- Create the stored procedure in the specified schema
CREATE PROCEDURE dbo.insert_has_class_type
    @class_id BIGINT,
    @class_type_id_list CLASS_TYPE_ID_LIST READONLY
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY 
        -- can be updated for the update use-case
        -- checking for class_id
        IF NOT EXISTS 
            (
                SELECT 1
                FROM dbo.class c  
                WHERE c.class_id = @class_id
            )
        THROW 50003, 'Class has been altered or deleted', 1;

        -- checking for class_id_type
        IF EXISTS 
            (
                SELECT 1
                FROM @class_type_id_list l 
                WHERE l.class_type_id NOT IN 
                (
                    SELECT ct.class_type_id
                    FROM dbo.class_type ct
                )
            )
        THROW 50005, 'One or more class types do not exist', 1;

        -- delete from update
        DELETE FROM dbo.has_class_type
        WHERE class_id = @class_id;

        INSERT INTO dbo.has_class_type(class_id, class_type_id)
        SELECT @class_id, l.class_type_id
        FROM @class_type_id_list l;
    END TRY 

    BEGIN CATCH 
        -- For debugging as SA
        SELECT ERROR_LINE() AS [error line],
        ERROR_MESSAGE() AS [message],
        ERROR_NUMBER() AS [number],
        ERROR_PROCEDURE() AS [procedure],
        ERROR_SEVERITY() AS [severity],
        ERROR_STATE() AS [state];

        -- For application to show error
        THROW;
    END CATCH

END
go

