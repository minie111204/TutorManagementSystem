CREATE FUNCTION Calculate_Revenue_All()
RETURNS @ResultProfit TABLE (
    Current_Revenue     DECIMAL(18, 2) NULL,
    Expected_Revenue    DECIMAL(18, 2) NULL,
    Discount_Revenue    DECIMAL(18, 2) NULL  
)
AS
BEGIN
    -- Khai báo biến lưu giá trị tổng
    DECLARE @Current_Revenue DECIMAL(18, 2) = 0,
            @Expected_Revenue DECIMAL(18, 2) = 0,
            @Discount_Revenue DECIMAL(18, 2) = 0;

    -- Bảng tạm chứa dữ liệu kết hợp
    DECLARE @TempTable TABLE (
        ClassID INT,
        Commission_Fee DECIMAL(18, 2),
        BillMoney DECIMAL(18, 2),
        BillStatus NVARCHAR(50),
        BillType NVARCHAR(50)
    );
    -- Chèn dữ liệu vào bảng tạm
    INSERT INTO @TempTable (ClassID, Commission_Fee, BillMoney, BillStatus, BillType)
    SELECT 
        C.class_id,
        C.commission_fee,
        B.bill_money,
        B.bill_status,
        B.bill_type
    FROM [Ass2_CO2013].[dbo].class C
    LEFT JOIN [Ass2_CO2013].[dbo].belongs_to BE ON C.class_id = BE.class_id
    LEFT JOIN [Ass2_CO2013].[dbo].bill B ON BE.bill_id = B.bill_id;

    -- Khai báo con trỏ (Cursor) để duyệt qua bảng tạm
    DECLARE temp_cursor CURSOR FOR
    SELECT ClassID, Commission_Fee, BillMoney, BillStatus, BillType
    FROM @TempTable;

    -- Biến để lưu dữ liệu trong mỗi lần duyệt
    DECLARE @ClassID INT,
            @Commission_Fee DECIMAL(18, 2),
            @BillMoney DECIMAL(18, 2),
            @BillStatus NVARCHAR(50),
            @BillType NVARCHAR(50);

    -- Mở con trỏ
    OPEN temp_cursor;

    -- Đọc từng dòng
    FETCH NEXT FROM temp_cursor INTO @ClassID, @Commission_Fee, @BillMoney, @BillStatus, @BillType;

    WHILE @@FETCH_STATUS = 0
    BEGIN
    
        -- Cộng dồn doanh thu kỳ vọng
        IF (@Commission_Fee >0) SET @Expected_Revenue =@Expected_Revenue + @Commission_Fee;

        -- Cộng dồn doanh thu thực tế và giảm giá
        IF @BillStatus = 'Xac nhan' AND @BillType = 'Phi hoa hong'
        BEGIN
            SET @Current_Revenue += @BillMoney;

            IF @BillMoney < @Commission_Fee
                SET @Discount_Revenue += (@Commission_Fee - @BillMoney);
        END;

        -- Đọc dòng tiếp theo
        FETCH NEXT FROM temp_cursor INTO @ClassID, @Commission_Fee, @BillMoney, @BillStatus, @BillType;
    END;

    -- Đóng và giải phóng con trỏ
    CLOSE temp_cursor;
    DEALLOCATE temp_cursor;

    -- Chèn kết quả vào bảng trả về
    INSERT INTO @ResultProfit (Current_Revenue, Expected_Revenue, Discount_Revenue)
    VALUES (@Current_Revenue, @Expected_Revenue, @Discount_Revenue);

    RETURN;
END;
go

